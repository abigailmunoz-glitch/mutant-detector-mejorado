package com.mercadolibre.mutantdetector.service;

import com.mercadolibre.mutantdetector.dto.StatsResponse;
import com.mercadolibre.mutantdetector.repository.DnaRecordRepository;
import org.springframework.stereotype.Service;

@Service
public class StatsService {

    private final DnaRecordRepository dnaRecordRepository;

    public StatsService(DnaRecordRepository dnaRecordRepository) {
        this.dnaRecordRepository = dnaRecordRepository;
    }

    public StatsResponse getStats() {
        long countMutantDna = dnaRecordRepository.countMutantDna();
        long countHumanDna = dnaRecordRepository.countHumanDna();

        return new StatsResponse(countMutantDna, countHumanDna);
    }
}