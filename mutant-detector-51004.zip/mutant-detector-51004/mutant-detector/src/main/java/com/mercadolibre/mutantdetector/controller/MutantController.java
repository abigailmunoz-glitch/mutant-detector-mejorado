package com.mercadolibre.mutantdetector.controller;

import com.mercadolibre.mutantdetector.dto.DnaRequest;
import com.mercadolibre.mutantdetector.dto.StatsResponse;
import com.mercadolibre.mutantdetector.service.MutantService;
import com.mercadolibre.mutantdetector.service.StatsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
public class MutantController {

    private final MutantService mutantService;
    private final StatsService statsService;

    public MutantController(MutantService mutantService, StatsService statsService) {
        this.mutantService = mutantService;
        this.statsService = statsService;
    }

    @PostMapping("/mutant")
    @Operation(summary = "Analiza si un ADN es mutante")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "ADN mutante detectado"),
            @ApiResponse(responseCode = "403", description = "ADN humano"),
            @ApiResponse(responseCode = "400", description = "ADN inválido")
    })
    public ResponseEntity<Void> isMutant(@Valid @RequestBody DnaRequest dnaRequest) {
        boolean isMutant = mutantService.isMutant(dnaRequest.getDna());

        if (isMutant) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.status(403).build();
        }
    }

    @GetMapping("/stats")
    @Operation(summary = "Obtiene estadísticas de ADN analizados")
    @ApiResponse(responseCode = "200", description = "Estadísticas devueltas con éxito")
    public ResponseEntity<StatsResponse> getStats() {
        StatsResponse stats = statsService.getStats();
        return ResponseEntity.ok(stats);
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Void> handleBadRequest(IllegalArgumentException ex) {
        return ResponseEntity.badRequest().build();
    }
}