package com.mercadolibre.mutantdetector.service;

import org.springframework.stereotype.Component;
import java.util.HashSet;
import java.util.Set;

@Component
public class MutantDetector {

    private static final int SEQUENCE_LENGTH = 4;
    private static final Set<Character> VALID_BASES = Set.of('A', 'T', 'C', 'G');

    public boolean isMutant(String[] dna) {
        validateInput(dna);

        int n = dna.length;
        char[][] matrix = convertToMatrix(dna);
        int sequenceCount = 0;

        // Buscar secuencias
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                // Si ya tenemos más de 1 secuencia, retornar
                if (sequenceCount > 1) return true;

                // Horizontal (→)
                if (j <= n - SEQUENCE_LENGTH) {
                    if (checkSequence(matrix, i, j, 0, 1)) {
                        sequenceCount++;
                        j += SEQUENCE_LENGTH - 1; // Saltar para no revisitar
                        continue;
                    }
                }

                // Vertical (↓)
                if (i <= n - SEQUENCE_LENGTH) {
                    if (checkSequence(matrix, i, j, 1, 0)) {
                        sequenceCount++;
                        continue;
                    }
                }

                // Diagonal principal (↘)
                if (i <= n - SEQUENCE_LENGTH && j <= n - SEQUENCE_LENGTH) {
                    if (checkSequence(matrix, i, j, 1, 1)) {
                        sequenceCount++;
                        continue;
                    }
                }

                // Diagonal secundaria (↙)
                if (i <= n - SEQUENCE_LENGTH && j >= SEQUENCE_LENGTH - 1) {
                    if (checkSequence(matrix, i, j, 1, -1)) {
                        sequenceCount++;
                    }
                }
            }
        }

        return sequenceCount > 1;
    }

    private boolean checkSequence(char[][] matrix, int startRow, int startCol, int rowStep, int colStep) {
        char firstChar = matrix[startRow][startCol];

        for (int k = 1; k < SEQUENCE_LENGTH; k++) {
            int currentRow = startRow + k * rowStep;
            int currentCol = startCol + k * colStep;

            if (matrix[currentRow][currentCol] != firstChar) {
                return false;
            }
        }
        return true;
    }

    private void validateInput(String[] dna) {
        if (dna == null || dna.length < SEQUENCE_LENGTH) {
            throw new IllegalArgumentException("DNA array cannot be null or have less than " + SEQUENCE_LENGTH + " sequences");
        }

        int n = dna.length;
        for (int i = 0; i < n; i++) {
            String sequence = dna[i];
            if (sequence == null || sequence.length() != n) {
                throw new IllegalArgumentException("DNA matrix must be NxN. Row " + i + " has invalid length");
            }

            for (int j = 0; j < n; j++) {
                char base = sequence.charAt(j);
                if (base >= 'a' && base <= 'z') {
                    throw new IllegalArgumentException(
                            String.format("DNA must be uppercase. Invalid base '%c' at position [%d][%d].", base, i, j)
                    );
                }
                if (!VALID_BASES.contains(base)) {
                    throw new IllegalArgumentException(
                            String.format("Invalid DNA base '%c' at position [%d][%d]. Only A, T, C, G are allowed.", base, i, j)
                    );
                }
            }
        }
    }

    private char[][] convertToMatrix(String[] dna) {
        int n = dna.length;
        char[][] matrix = new char[n][n];
        for (int i = 0; i < n; i++) {
            matrix[i] = dna[i].toCharArray();
        }
        return matrix;
    }
}