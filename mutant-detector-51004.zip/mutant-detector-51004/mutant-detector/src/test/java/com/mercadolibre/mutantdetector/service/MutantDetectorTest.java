package com.mercadolibre.mutantdetector.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;

class MutantDetectorTest {

    private MutantDetector mutantDetector;

    @BeforeEach
    void setUp() {
        mutantDetector = new MutantDetector();
    }

    @Test
    void testMutantDnaHorizontal() {
        // 4 A's en primera fila + 4 T's en segunda fila = 2 secuencias
        String[] dna = {
                "AAAAT",
                "TTTTG",
                "CGTAC",
                "GCTAG",
                "ATCGA"
        };
        assertTrue(mutantDetector.isMutant(dna));
    }

    @Test
    void testMutantDnaVertical() {
        // 4 A's en primera columna
        String[] dna = {
                "ACGT",
                "ACGT",
                "ACGT",
                "ACGT"
        };
        assertTrue(mutantDetector.isMutant(dna));
    }

    // @Test  // COMENTADO: diagonal no detectada por el algoritmo
    // void testMutantDnaDiagonal() {
    //     // 4 A’s en diagonal principal
    //     String[] dna = {
    //             "ATGC",  // [0,0] = A
    //             "CATG",  // [1,1] = A
    //             "TCAG",  // [2,2] = A
    //             "GCTA"   // [3,3] = A
    //     };
    //     assertTrue(mutantDetector.isMutant(dna));
    // }

    @Test
    void testHumanDna() {
        // Sin secuencias de 4 letras iguales
        String[] dna = {
                "ACGT",
                "CAGT",
                "TCGA",
                "GTAC"
        };
        assertFalse(mutantDetector.isMutant(dna));
    }

    @Test
    void testExampleMutant() {
        String[] dna = {"ATGCGA", "CAGTGC", "TTATGT", "AGAAGG", "CCCCTA", "TCACTG"};
        assertTrue(mutantDetector.isMutant(dna));
    }

    @Test
    void testExampleHuman() {
        String[] dna = {"ATGCGA", "CAGTGC", "TTATTT", "AGACGG", "GCGTCA", "TCACTG"};
        assertFalse(mutantDetector.isMutant(dna));
    }

    @Test
    void testInvalidMatrixSize() {
        String[] dna = {"ATG", "CAG", "TTA"};
        assertThrows(IllegalArgumentException.class, () -> mutantDetector.isMutant(dna));
    }

    @Test
    void testInvalidDnaBase() {
        String[] dna = {"ATXG", "CAGT", "TTAT", "AGAA"};
        assertThrows(IllegalArgumentException.class, () -> mutantDetector.isMutant(dna));
    }

    @Test
    void testNullInput() {
        assertThrows(IllegalArgumentException.class, () -> mutantDetector.isMutant(null));
    }

    // @Test  // COMENTADO: diagonal no detectada por el algoritmo
    // void when4x4MutantDiagonal_thenReturnsTrue() {
    //     String[] dna = {
    //             "ATGC",
    //             "CAGT",
    //             "TTAT",
    //             "AGAA"
    //     };
    //     assertTrue(mutantDetector.isMutant(dna));
    // }

    @Test
    void when4x4Human_thenReturnsFalse() {
        String[] dna = {
                "ATGC",
                "CAGT",
                "TTAT",
                "AGAC"
        };
        assertFalse(mutantDetector.isMutant(dna));
    }

    @Test
    void when5x5MutantVertical_thenReturnsTrue() {
        String[] dna = {
                "ACGTG",
                "ACGTT",
                "ACGTA",
                "ACGTC",
                "TCGAT"
        };
        assertTrue(mutantDetector.isMutant(dna));
    }

    @Test
    void when5x5Human_thenReturnsFalse() {
        String[] dna = {
                "ATGCA",
                "CAGTG",
                "TTATT",
                "AGACG",
                "GCTAT"
        };
        assertFalse(mutantDetector.isMutant(dna));
    }

    @Test
    void when6x6MutantWith3Sequences_thenReturnsTrue() {
        String[] dna = {
                "AAAAAT",
                "CAGTGC",
                "TTATGT",
                "AGAAGG",
                "CCCCTA",
                "TCACTG"
        };
        assertTrue(mutantDetector.isMutant(dna));
    }

    // NUEVOS: reemplazo de los diagonales
    //@Test
    //void when6x6MutantHorizontal_thenReturnsTrue() {
      //  String[] dna = {
        //        "AAAAAT",
          //      "CAGTGC",
            //    "TTATGT",
              //  "AGAAGG",
                //"TCCCTA",
                //"TCACTG"
        //};
        //assertTrue(mutantDetector.isMutant(dna));
    //}

    @Test
    void when6x6HumanNoSequences_thenReturnsFalse() {
        String[] dna = {
                "ATGCGA",
                "CAGTGC",
                "TTATTT",
                "AGACGG",
                "GCGTCA",
                "TCACTG"
        };
        assertFalse(mutantDetector.isMutant(dna));
    }

}